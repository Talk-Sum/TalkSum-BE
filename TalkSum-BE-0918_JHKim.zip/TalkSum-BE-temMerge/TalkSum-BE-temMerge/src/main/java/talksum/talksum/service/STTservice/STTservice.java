package talksum.talksum.service.STTservice;

public interface STTservice {

    String executeSTT(String fileName) throws Exception;
}
